Portfolio website for Osamah Ali

Files included:
- index.html
- style.css
- script.js

How to use:
1. Open index.html in any browser.
2. Edit text directly inside index.html.
3. Replace contact details or add project links if needed.
4. Host on GitHub Pages, Netlify, Vercel, or any standard web host.

Suggested next improvements:
- Add your real profile photo
- Add CV download button
- Add actual project screenshots
- Connect contact form to Formspree or EmailJS
